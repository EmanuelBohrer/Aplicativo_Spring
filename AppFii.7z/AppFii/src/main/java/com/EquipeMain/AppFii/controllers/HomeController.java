package com.EquipeMain.AppFii.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.EquipeMain.AppFii.repository.FundoRepository;

@Controller
public class HomeController {
	
	
	@Autowired
	private FundoRepository fp;
	
	
	@RequestMapping("/inicial")
	public String inicial () {
		return "login/login_user";
		
	}
	

}
