package com.EquipeMain.AppFii.enums;

public enum StatusLancamento {
	
	PENDENTE,
	CANCELADO,
	EFETIVADO
	

}
