package com.EquipeMain.AppFii;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppFiiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppFiiApplication.class, args);
	}

}
