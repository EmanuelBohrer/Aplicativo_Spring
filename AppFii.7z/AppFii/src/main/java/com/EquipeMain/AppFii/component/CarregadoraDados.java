package com.EquipeMain.AppFii.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import com.EquipeMain.AppFii.models.Papel;
import com.EquipeMain.AppFii.repository.PapelRepository;


@Component
public class CarregadoraDados implements CommandLineRunner {

	@Autowired
	private PapelRepository pr;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		String [] papeis = {"ADMIN","USER"};
		for (String papelString: papeis) {
			Papel papel = pr.findByPapel(papelString);
			if(papel == null) {
				papel = new Papel(papelString);
				pr.save(papel);
			}
		}
		
		
	}

}
