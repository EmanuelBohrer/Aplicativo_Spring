package com.EquipeMain.AppFii.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.EquipeMain.AppFii.repository.FundoRepository;
import com.EquipeMain.AppFii.repository.UsuarioRepository;

@Controller
public class AppController {
	
	@RequestMapping("/")
	public String index (Model model) {
		model.addAttribute("msnBem Vindo!, Bem vindo ao sistema AppFii");
		return "appFii/dashboard";
		
	}
	
	

	

}
