package com.EquipeMain.AppFii.controllers;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.EquipeMain.AppFii.models.Papel;
import com.EquipeMain.AppFii.models.Usuario;
import com.EquipeMain.AppFii.repository.PapelRepository;
import com.EquipeMain.AppFii.repository.UsuarioRepository;

@Controller
@RequestMapping("/usuario")
public class UsuarioController {
	
	
	@Autowired
	private UsuarioRepository rp;
	
	
	@Autowired
	private PapelRepository pr;
	
	
	@GetMapping("/novo")
	public String addUser(Model model) {
		model.addAttribute("usuario", new Usuario());
		return "login/cadastroUsuario";
		
		
	}
	
	@PostMapping("/salvar")
	public String salvarUser(@Valid Usuario usuario, BindingResult result, RedirectAttributes attributes,Model model) {
		
		if(result.hasErrors()) {
			return "login/cadastroUsuario";
		}
		
		Usuario user = rp.findByEmail(usuario.getEmail());
		if(user !=null) {
			model.addAttribute("emailExiste", "O email inserido já existe cadastrado.");
			return "login/cadastroUsuario";
			
		}
		
		Papel papel = pr.findByPapel("USER");
		List<Papel> papeis = new ArrayList<Papel>();
		papeis.add(papel);
		usuario.setPapeis(papeis);
		
		usuario.setData_cad(Instant.now());
		rp.save(usuario);
		attributes.addFlashAttribute("mensagem","Usuário cadastrado com sucesso, faça seu login.");
		return "redirect:/usuario/novo";

		
	}
	
	
	@RequestMapping("/admin/listar")
	public String listarUser(Model model) {
		model.addAttribute("usuarios",rp.findAll());
		return "/auth/admin/admin-listar-usuario";
		
	
	}
	
	@GetMapping("/admin/apagar/{id}")
	public String deleteUser(@PathVariable("id") long id, Model model) {
		Usuario usuario = rp.findById(id).orElseThrow(() -> new IllegalArgumentException("Id inserido : "+ id+ "não está cadastrado."));
		rp.delete(usuario);
		return"redirect:/usuario/admin/listar";
		
		
	}
	
	@GetMapping("/editar/{id}")
	public String editarUsuario(@PathVariable("id") long id, Model model) {
		Optional<Usuario> oldUser = rp.findById(id);
		if (!oldUser.isPresent()) {
            throw new IllegalArgumentException("Usuário inválido:" + id);
        } 
		Usuario usuario = oldUser.get();
	    model.addAttribute("usuario", usuario);
	    return "auth/user/editUser";
	}

	
	

}
	
	
	



