package com.EquipeMain.AppFii.enums;

public enum TipoLancamento {
	
	RECEITA,
	DESPESA,

}
