package com.EquipeMain.AppFii.service;

public class ServiceExc extends Exception {

	public ServiceExc(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	private static final long serialVersionUID = 1L;

}
