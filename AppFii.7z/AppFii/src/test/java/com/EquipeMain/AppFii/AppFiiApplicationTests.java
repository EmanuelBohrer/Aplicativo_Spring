package com.EquipeMain.AppFii;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppFiiApplicationTests {

	@Test
	void contextLoads() {
	}

}
